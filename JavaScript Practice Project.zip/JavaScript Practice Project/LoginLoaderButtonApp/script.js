const loadButton = document.getElementById('loaderButton');
const loader = document.getElementById('loader');
const demoForm = document.getElementById('my-form');

loadButton.addEventListener('click', () => {
    // Disable the button and prevent further clicks
    loadButton.disabled = true;
    loader.style.display = 'inline-block'; // Show loader
    loadButton.querySelector('.btn-text').style.display = 'none'; // Hide the button text

    setTimeout(() => {
        // Restore the button state after the operation is done
        loadButton.disabled = false;
        loader.style.display = 'none'; // Hide loader
        loadButton.querySelector('.btn-text').style.display = 'inline'; // Show the button text
        demoForm.reset(); // Reset form if needed
    }, 2000); // Simulate operation time of 2 seconds
});
    